<?php

$moduleTabRoot = array();
$moduleTabRoot['name'] = 'InventoryManager';
$moduleTabRoot['clase'] = 'AdminIM';
$moduleTabRoot['padre'] = '';
$moduleTabRoot['imagen'] = '';

$moduleTabs = array();
$moduleTabs[0] = array();
$moduleTabs[0]['name'] = 'Importador Inventory Manager';
$moduleTabs[0]['clase'] = 'AdminInventoryManager';
$moduleTabs[0]['padre'] = 'AdminIM';
$moduleTabs[0]['imagen'] = 'archive';
